package com.example.dailybalance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Fields that need to be accessed throughout the activity
    private EditText usernameField, passwordField;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize the SQLite Database Helper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI elements
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);

        // Initialize buttons as local variables since they are only used in onCreate
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Set login button click listener
        loginButton.setOnClickListener(v -> handleLogin());

        // Set create account button click listener
        createAccountButton.setOnClickListener(v -> handleAccountCreation());
    }

    /**
     * Function to handle user login.
     * It authenticates the user's input against the SQLite database.
     */
    private void handleLogin() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        // Validate that inputs are not empty
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(LoginActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Authenticate the user
        boolean isAuthenticated = dbHelper.authenticateUser(username, password);
        if (isAuthenticated) {
            Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Function to handle account creation.
     * It adds the user's input to the SQLite database after validation.
     */
    private void handleAccountCreation() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        // Validate that inputs are not empty
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(LoginActivity.this, "Please enter a username and password to create an account", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the username already exists
        if (dbHelper.doesUserExist(username)) {
            Toast.makeText(LoginActivity.this, "Username already exists. Please try a different one.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new user
        boolean isUserCreated = dbHelper.createUser(username, password);
        if (isUserCreated) {
            Toast.makeText(LoginActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            // Clear input fields
            usernameField.setText("");
            passwordField.setText("");
        } else {
            Toast.makeText(LoginActivity.this, "Failed to create an account. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
