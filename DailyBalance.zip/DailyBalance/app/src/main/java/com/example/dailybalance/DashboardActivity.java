package com.example.dailybalance;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    // Fields that need to be accessed throughout the activity
    private List<WeightEntry> weightEntries; // <--- Change List<String> to List<WeightEntry>
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI elements
        Button addEntryButton = findViewById(R.id.addEntryButton);
        RecyclerView weightGrid = findViewById(R.id.weightGrid);
        EditText weightInputField = findViewById(R.id.weightInputField);

        // Load weight entries from the database (this will return List<WeightEntry>)
        weightEntries = dbHelper.getAllWeightEntries();

        // Set up RecyclerView
        adapter = new WeightAdapter(weightEntries, dbHelper);
        weightGrid.setLayoutManager(new LinearLayoutManager(this));
        weightGrid.setAdapter(adapter);

        // Set click listener for adding entries
        addEntryButton.setOnClickListener(v -> {
            String weightInput = weightInputField.getText().toString().trim();
            if (!weightInput.isEmpty()) {
                String date = dbHelper.getCurrentDate(); // Get the current date
                boolean isInserted = dbHelper.addWeightEntry(date, weightInput);
                if (isInserted) {
                    // Add new entry to the weightEntries list as a WeightEntry object
                    WeightEntry newEntry = new WeightEntry(date, weightInput);
                    weightEntries.add(newEntry);
                    adapter.notifyItemInserted(weightEntries.size() - 1);
                    weightInputField.setText(""); // Clear input field
                    Toast.makeText(DashboardActivity.this, "Weight entry added successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(DashboardActivity.this, "Failed to add weight entry", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DashboardActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
