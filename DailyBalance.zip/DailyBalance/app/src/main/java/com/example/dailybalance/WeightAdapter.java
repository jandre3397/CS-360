package com.example.dailybalance;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final List<WeightEntry> weightEntries;
    private final DatabaseHelper dbHelper;

    // Constructor that takes a list of weight entries and a reference to DatabaseHelper
    public WeightAdapter(List<WeightEntry> weightEntries, DatabaseHelper dbHelper) {
        this.weightEntries = weightEntries;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_entry, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        // Get the current weight entry object
        WeightEntry entry = weightEntries.get(position);

        // Bind data to the view
        holder.weightTextView.setText(entry.getDate() + ": " + entry.getWeight() + " lbs");

        // Set click listener for the delete button
        holder.deleteButton.setOnClickListener(v -> {
            String date = entry.getDate(); // Extract the date from the entry

            // Delete from the database
            boolean isDeleted = dbHelper.deleteWeightEntry(date);

            if (isDeleted) {
                // Remove entry from the list and notify RecyclerView
                weightEntries.remove(position);
                notifyItemRemoved(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView;
        Button deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}

