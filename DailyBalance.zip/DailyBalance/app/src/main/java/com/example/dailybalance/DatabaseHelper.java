package com.example.dailybalance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "dailybalance.db";
    private static final int DATABASE_VERSION = 2; // Version incremented to apply the new table

    // User table columns
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Weight entries table columns
    public static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " + // username is unique
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);

        // Create Weight Entries Table
        String createWeightTable = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_WEIGHT + " REAL)";
        db.execSQL(createWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        onCreate(db);
    }

    // ------------- USER METHODS ------------- //

    /**
     * Inserts a new user into the database.
     */
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // return true if the insert was successful
    }

    /**
     * Authenticates a user by checking if the username and password match.
     */
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, password});

        boolean authenticated = cursor.getCount() > 0;
        cursor.close();
        return authenticated;
    }

    /**
     * Checks if a user exists in the database.
     */
    public boolean doesUserExist(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ?",
                new String[]{username});

        boolean userExists = cursor.getCount() > 0;
        cursor.close();
        return userExists;
    }

    // ------------- WEIGHT ENTRY METHODS ------------- //

    /**
     * Inserts a new weight entry into the database.
     */
    public boolean addWeightEntry(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        long result = db.insert(TABLE_WEIGHT_ENTRIES, null, values);
        return result != -1; // Return true if the entry was successfully added
    }

    /**
     * Gets all weight entries from the database.
     */
    public List<WeightEntry> getAllWeightEntries() {
        List<WeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT date, weight FROM " + TABLE_WEIGHT_ENTRIES, null);

        if (cursor.moveToFirst()) {
            int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
            int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

            // Make sure columns are found
            if (dateIndex != -1 && weightIndex != -1) {
                do {
                    String date = cursor.getString(dateIndex);
                    String weight = cursor.getString(weightIndex);
                    entries.add(new WeightEntry(date, weight));
                } while (cursor.moveToNext());
            } else {
                Log.e("DB_ERROR", "One of the columns does not exist in the query.");
            }
        }
        cursor.close();
        return entries;
    }

    /**
     * Updates a weight entry in the database.
     */
    public boolean updateWeightEntry(String date, String newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);
        int rowsAffected = db.update(TABLE_WEIGHT_ENTRIES, values, COLUMN_DATE + " = ?", new String[]{date});
        return rowsAffected > 0; // Return true if the update was successful
    }

    /**
     * Deletes a weight entry from the database.
     */
    public boolean deleteWeightEntry(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_WEIGHT_ENTRIES, COLUMN_DATE + " = ?", new String[]{date});
        return result > 0; // Return true if the row was successfully deleted
    }

    /**
     * Gets the current date in YYYY-MM-DD format.
     */
    public String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }
}
